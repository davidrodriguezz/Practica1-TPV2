Like ecs_4 but works with messages that are defined using inheritance (they need to have a clone method)
