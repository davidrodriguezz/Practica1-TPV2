// This file is part of the course TPV2@UCM - Samir Genaim

#include "B.h"
#include "C.h"

int main() {

	B x;
	C<int> y;

	x.foo(1);
	y.moo(1);

	return 0;
}
