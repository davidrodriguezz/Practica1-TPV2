// This file is part of the course TPV2@UCM - Samir Genaim

template<typename T>
class uptr {
	T *p_;
public:
	uptr(const T&) = delete;
	uptr<T>& operator=(const uptr<T>&) = delete;

	uptr() :
			p_(nullptr) {
	}

	uptr(T *p) :
			p_(p) {
	}

	uptr(uptr<T> &&o) {
		p_ = o.p_;
		o.p_ = nullptr;
	}

	~uptr() {
		reset(nullptr);
	}

	uptr<T>& operator=(uptr<T> &&o) {
		reset(nullptr);
		p_ = o.p_;
		o.p_ = nullptr;
		return *this;
	}

	T* operator->() {
		return p_;
	}

	T& operator*() {
		return *p_;
	}

	T* get() {
		return p_;
	}

	void reset(T *p) {
		if (p_ != nullptr)
			delete p_;
		p_ = p;
	}
};
