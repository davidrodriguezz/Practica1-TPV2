// This file is part of the course TPV2@UCM - Samir Genaim
#include <memory>

template<typename T>
class shptr {
	T *p_;
	int *c_;
public:

	shptr() :
			p_(nullptr), c_(nullptr) {
	}

	shptr(T *p) :
			p_(nullptr), c_(nullptr) {
		reset(p);
	}

	shptr(const shptr<T> &o) {
		p_ = o.p_;
		c_ = o.c_;
		if (p_ != nullptr)
			(*c_)++;
	}

	shptr(shptr<T> &&o) {
		p_ = o.p_;
		c_ = o.c_;
		o.p_ = nullptr;
		o.c_ = nullptr;
	}

	~shptr() {
		reset(nullptr);
	}

	shptr<T>& operator=(const shptr<T> &o) {
		reset(nullptr);
		p_ = o.p_;
		c_ = o.c_;
		if (p_ != nullptr)
			(*c_)++;
		return *this;
	}

	shptr<T>& operator=(shptr<T> &&o) {
		std::shared_ptr<int> x;
		reset(nullptr);
		p_ = o.p_;
		c_ = o.c_;
		o.p_ = nullptr;
		o.c_ = nullptr;
		return *this;
	}

	T* operator->() {
		return p_;
	}

	T& operator*() {
		return *p_;
	}

	T* get() {
		return p_;
	}

	void reset(T *p) {
		if (p_ != nullptr) {
			(*c_)--;
			if (*c_ == 0) {
				delete p_;
				delete c_;
			}
		}
		p_ = p;
		if (p != nullptr)
			c_ = new int(1);
		else
			c_ = nullptr;
	}
};

