// This file is part of the course TPV2@UCM - Samir Genaim
#include <iostream>
#include "uptr.h"
#include "shptr.h"

class A {
public:
	virtual ~A() {
		std::cout << "A: dtor." << std::endl;
	}
	void foo() {
		std::cout << "foo" << std::endl;
	}
};

void f() {
	uptr<A> x(new A());
	x->foo();
}

void g() {
	shptr<A> x(new A());
	x->foo();
}

int main() {

	f();
	g();

	return 0;
}
