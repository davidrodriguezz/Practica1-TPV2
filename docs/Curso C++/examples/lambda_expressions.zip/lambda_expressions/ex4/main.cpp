// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>
#include <functional>

class A {
};

void foo(std::function<void(int)> f) {
	int x = 3;
	f(x);
}

int main(int, char**) {
	int x = 1;
	foo([&x](int i) {
		x = i;
	});
	std::cout << x << std::endl;

	return 0;
}
