// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>

int p(int x, int y) {
	return x + y;
}

int m(int x, int y) {
	return x * y;
}

void foo(int (*f)(int, int)) {
	std::cout << f(3, 4) << std::endl;
}

int main(int, char**) {
	foo(p);
	foo(m);

	return 0;
}
