// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once
#include <memory>
#include <type_traits>

template<typename RT, typename ...Ts>
class callable_base {
public:
	virtual RT operator()(Ts &&...args) = 0;
	virtual ~callable_base() {
	}
	virtual callable_base<RT, Ts...>* clone() = 0;
};

template<typename F, typename RT, typename ... Ts>
class callable: callable_base<RT, Ts...> {
	F f_;
public:

	callable(F functor) :
			f_(functor) {
	}

	RT operator()(Ts &&...args) override {
		return f_(std::forward<Ts>(args)...);
	}

	callable_base<RT, Ts...>* clone() override {
		return new callable<F, RT, Ts...>(f_);
	}

};

template<typename, typename ...>
class func;

template<typename RT, typename ... Ts>
class func<RT(Ts...)> {

	using this_type = func<RT(Ts...)>;

	std::unique_ptr<callable_base<RT, Ts...>> c_;
public:

	template<typename F>
	func(F f) {
		c_.reset(new callable<F, RT, Ts...>(f));
	}

	func(const this_type &o) {
		c_.reset(o.c_.get()->clone());
	}

	func(this_type &&o) {
		c_ = std::move(o.c_);
	}

	auto& operator=(const this_type &o) {
		c_.reset(o.c_.get()->clone());
		return *this;
	}

	auto& operator=(this_type &&o) {
		c_ = std::move(o.c_);
		return *this;
	}

	template<typename F>
	auto& operator=(const F &f) {
		c_.reset(new callable<F, RT, Ts...>(f));
		return *this;
	}

	RT operator()(Ts &&... args) {
		return (*c_)(std::forward<Ts>(args)...);
	}
};

