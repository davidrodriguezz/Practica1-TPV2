#include <iostream>


void foo(std::function<int(int)> f) {
	std::cout << f(10) << std::endl;
}


int main() {

	auto f = [](int x) {
		return x + 1;
	};

	foo(f);

	return 0;
}
