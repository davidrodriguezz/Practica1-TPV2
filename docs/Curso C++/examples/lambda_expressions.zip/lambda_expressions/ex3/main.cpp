// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>
#include <functional>

void foo(std::function<int(int, int)> f) {
	std::cout << f(3, 4) << std::endl;
}

int main(int, char**) {
	int x = 1;
	int y = 3;

	auto f1 = [](int i, int j) mutable -> int {
		return i + j;
	};

	auto f2 = [x, y](int i, int j) {
		return i + j + x + y;
	};

	foo(f1);
	foo(f2);

	return 0;
}

