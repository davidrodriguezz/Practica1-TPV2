// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>
#include <functional>

std::function<int()> p() {
	int x = 1;
	return [&x]() {
		return x;
	};
}

std::function<void(int)> q() {
	int z = 1;
	return [&z](int i) {
		z = i;
	};
}

int main(int, char**) {
	auto f = p();
	auto h = q();
	h(5);
	std::cout << f() << std::endl;

	return 0;
}
