// This file is part of the course TPV2@UCM - Samir Genaim

#include <iostream>
#include <functional>

class A {
public:
	A(int x) :
			x_(x) {
	}
	virtual ~A() {
	}
	int getX() {
		return x_;
	}

	std::function<void(int)> createF() {
		return [this](int i) {
			x_ = i;
		};
	}
private:
	int x_;
};

int main(int, char**) {
	A a(5);
	auto f = a.createF();
	f(0);
	std::cout << a.getX() << std::endl;

	return 0;
}
