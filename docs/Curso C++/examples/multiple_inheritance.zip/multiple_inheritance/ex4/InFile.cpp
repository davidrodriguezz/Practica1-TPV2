#include "InFile.h"

#include <iostream>

using namespace std;

InFile::InFile() {
}

InFile::~InFile() {
}

void InFile::open() {
	cout << "Opening (in read) ..." << endl;
}

void InFile::read() {
    cout << "reading ..." << endl;
}

