#include "OutFile.h"

#include <iostream>

using namespace std;

OutFile::OutFile() {
}

OutFile::~OutFile() {
}

void OutFile::open() {
	cout << "Opening (in write) ..." << endl;
}

void OutFile::write() {
	cout << "writing ..." << endl;
}
