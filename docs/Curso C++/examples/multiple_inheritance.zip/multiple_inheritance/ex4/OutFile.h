#pragma once

/*
 *
 */
class OutFile {
public:
	OutFile();
	virtual ~OutFile();
	void open();
    void write();
};
