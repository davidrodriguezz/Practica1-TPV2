#pragma once

/*
 *
 */
class InFile {
public:
	InFile();
	virtual ~InFile();
	void open();
    void read();
};
