#include <iostream>


class Engineer {
public:
    // 40 APIs
};

class Son {
public:
    // 50 APIs
};

class Andy : public Engineer, public Son {
public:
    // 400 APIs
};

void colleague(Engineer& a) {
    // talk to Andy as an Engineer
}

void parents(Son& a) {
    // talk to Andy as son
}

int main(int ac, char** av) {
    Andy x;
    
    colleague(x);
    parents(x);
    return 0;
}

