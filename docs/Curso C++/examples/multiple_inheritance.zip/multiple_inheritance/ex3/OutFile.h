#pragma once

/*
 *
 */
class OutFile {
public:
	OutFile();
	virtual ~OutFile();
    void write();
};
