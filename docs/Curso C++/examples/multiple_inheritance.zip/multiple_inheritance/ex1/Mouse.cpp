#include "Mouse.h"

Mouse::Mouse() :
		button(NONE), x(0), y(0) {
}

Mouse::~Mouse() {
}

Mouse::Button Mouse::getClickedButton() {
	return button;
}

int Mouse::getClickedX() {
	return x;
}

int Mouse::getClickedY() {
	return y;
}

void Mouse::click(Button b, int x, int y) {
	button = b;
	this->x = x;
	this->y = y;

}

