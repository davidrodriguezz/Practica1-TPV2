
#include <iostream>

#include "Keyboard.h"
#include "KMCombo.h"
#include "Mouse.h"

using namespace std;


void press_any_keyt(Keyboard& k) {
    char c;
    cout << "Press any key ..." << endl;
    cin >> c;
    k.press(c);
}

void click_anywhere(Mouse& m) {
    int x, y;
    cout << "Click somewhere ..." << endl;
    cin >> x >> y;
    m.click(Mouse::Button::LEFT, x ,y);
}


int main(int ac, char** av) {
    KMCombo c;

    press_any_keyt(c);
    click_anywhere( c);

    cout << c.getPressedKey() << endl;
    cout << c.getClickedX() << " " << c.getClickedY() << endl;

    return 0;
}
