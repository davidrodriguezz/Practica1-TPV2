#pragma once

/*
 *
 */
class Keyboard {
public:
	Keyboard();
	virtual ~Keyboard();
    char getPressedKey();
    void press(char x);

private:
    char key_;

};

