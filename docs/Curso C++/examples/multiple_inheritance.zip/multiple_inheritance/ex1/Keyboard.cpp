#include "Keyboard.h"

Keyboard::Keyboard() :
		key_(0) {
}

Keyboard::~Keyboard() {
}

char Keyboard::getPressedKey() {
	return key_;
}

void Keyboard::press(char c) {
	key_ = c;
}

