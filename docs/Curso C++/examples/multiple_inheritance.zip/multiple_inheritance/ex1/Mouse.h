#pragma once

/*
 *
 */
class Mouse {
public:
	enum Button {
		NONE, LEFT, CENTER, RIGHT
	};

	Mouse();
	virtual ~Mouse();
	Button getClickedButton();
	int getClickedX();
	int getClickedY();
	void click(Button b, int x, int y);

private:
	Button button;
	int x;
	int y;
};

