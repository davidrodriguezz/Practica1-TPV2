#pragma once

#include "Keyboard.h"
#include "Mouse.h"

/*
 *
 */
class KMCombo: public Keyboard, public Mouse {
public:
	KMCombo();
	virtual ~KMCombo();

};

