#pragma once

#include "InFile.h"
#include "OutFile.h"

/*
 *
 */
class IOFile: public InFile, public OutFile {
public:
	IOFile();
	virtual ~IOFile();
};
