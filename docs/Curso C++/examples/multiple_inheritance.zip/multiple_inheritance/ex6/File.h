#pragma once

#include <string>

using namespace std;

/*
 *
 */
class File {
public:
	File();
	virtual ~File();
	void open(string name);
	string getName();
protected:
	string name_;
};
