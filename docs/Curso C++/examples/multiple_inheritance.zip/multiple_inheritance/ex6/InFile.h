#pragma once

#include "File.h"

/*
 *
 */
class InFile : virtual public File {
public:
	InFile();
	virtual ~InFile();
    void read();
};

