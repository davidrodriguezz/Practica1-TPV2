#include "File.h"

#include <iostream>

File::File() {
	name_ = "";
}

File::~File() {
}

void File::open(string name) {
	name_ = name;
	cout << "Opening " << name_ << endl;
}

string File::getName() {
	return name_;
}
