#include "IOFile.h"

IOFile::IOFile() {
}

IOFile::~IOFile() {
}

