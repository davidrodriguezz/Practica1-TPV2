#pragma once

#include "File.h"

/*
 *
 */
class OutFile : public File {
public:
	OutFile();
	virtual ~OutFile();
    void write();
};
