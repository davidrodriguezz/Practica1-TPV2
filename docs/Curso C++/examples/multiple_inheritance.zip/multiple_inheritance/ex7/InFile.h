#pragma once

#include "File.h"

/*
 *
 */
class InFile : virtual public File {
public:
	InFile(string name);
	virtual ~InFile();
    void read();
};

