#include "InFile.h"

#include <iostream>

using namespace std;

InFile::InFile(string name) : File(name) {
}

InFile::~InFile() {
}

void InFile::read() {
    cout << "reading ..." << endl;
}

