#include <iostream>

#include "Animal.h"
#include "Dog.h"
#include "Drawing.h"


using namespace std;


void feed_animal(Animal& a) {
    a.eat();
}

void draw_on_canvas(Drawing& d) {
    d.draw();
}

int main(int ac, char** av) {
    Dog d;
    
    feed_animal(d);
    draw_on_canvas(d);

    return 0;

}
