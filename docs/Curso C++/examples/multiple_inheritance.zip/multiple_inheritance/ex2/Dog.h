#pragma once

#include <iostream>

#include "Animal.h"
#include "Drawing.h"

using namespace std;

/*
 *
 */
class Dog : public Animal, public Drawing {
public:
	Dog();
	virtual ~Dog();
	void eat();
	void draw();
};
