#pragma once

/*
 *
 */
class Animal {
public:
	Animal();
	virtual ~Animal();
	void virtual eat(/* some args */) = 0;
};

