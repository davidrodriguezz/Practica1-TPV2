#pragma once

#include "PhysicalObject.h"

/*
 *
 */
class CollisionManger {
public:
	CollisionManger();
	virtual ~CollisionManger();
	bool checkCollision(PhysicalObject* a, PhysicalObject* b);
private:
	bool checkCollision_(PhysicalObject* a, PhysicalObject* b);
};
