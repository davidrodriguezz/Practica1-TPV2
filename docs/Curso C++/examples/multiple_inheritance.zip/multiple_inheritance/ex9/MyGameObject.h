#pragma once

#include "GameObject.h"
#include "PhysicalObject.h"

/*
 *
 */
class MyGameObject : public GameObject, public PhysicalObject {
public:
	MyGameObject(double width, double height, double x, double y);
	virtual ~MyGameObject();
	virtual double getObjectWidth();
	virtual double getObjectHeight();
	virtual double getObjectXPos();
	virtual double getObjectYPos();
	virtual void render() = 0;
	virtual void update() = 0;

};
