#include "Enemy.h"

#include <iostream>

using namespace std;

Enemy::Enemy(double width, double height, double x, double y) : MyGameObject(width,height,x,y)  {
}

Enemy::~Enemy() {
}


void Enemy::render() {
	cout << "The Enemy is at position (" << x_ << "," << y_
			<< ") and its size is (" << width_ << "," << height_ << ")" << endl;
}

void Enemy::update() {
	x_ += 1;
	y_ += 1;
}
