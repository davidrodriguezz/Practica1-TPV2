#include <iostream>

#include "CollisionManger.h"
#include "Enemy.h"
#include "GameEngine.h"
#include "Hero.h"
#include "GameObject.h"
#include "PhysicalObject.h"

using namespace std;

void game() {

	GameEngine e;
	CollisionManger c;

	Hero a(5, 5, 10, 10);
	Enemy b(5, 5, 12, 12);

	e.addGameObject(&a);
	e.addGameObject(&b);

	e.render();

	cout << "collision? " << (c.checkCollision(&a, &b) ? "Yes" : "No") << endl;

	e.update();
	e.render();
	cout << "collision? " << (c.checkCollision(&a, &b) ? "Yes" : "No") << endl;
}

int main(int ac, char** av) {
	game();
    return 0;
}
