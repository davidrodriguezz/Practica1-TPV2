#pragma once

#include <vector>

#include "GameObject.h"

/*
 *
 */
class GameEngine {
public:
	GameEngine();
	virtual ~GameEngine();
	void addGameObject(GameObject* o);
	void update();
	void render();
private:
	std::vector<GameObject*> actors_;
};
