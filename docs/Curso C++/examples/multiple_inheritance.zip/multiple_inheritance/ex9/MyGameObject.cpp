#include "MyGameObject.h"

MyGameObject::MyGameObject(double width, double height, double x, double y) :
   GameObject(width, height, x, y) {
}

MyGameObject::~MyGameObject() {
}

double MyGameObject::getObjectWidth() {
	return width_;
}

double MyGameObject::getObjectHeight() {
	return height_;
}

double MyGameObject::getObjectXPos() {
	return x_;
}

double MyGameObject::getObjectYPos() {
	return y_;
}
