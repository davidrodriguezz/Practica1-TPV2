#include "GameObject.h"


GameObject::GameObject(double width, double height, double x, double y) {
	x_ = x;
	y_ = y;
	width_ = width;
	height_ = height;
}

GameObject::~GameObject() {
}

