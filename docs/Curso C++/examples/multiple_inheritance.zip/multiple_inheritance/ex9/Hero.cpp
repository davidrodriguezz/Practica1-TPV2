#include "Hero.h"

#include <iostream>

using namespace std;

Hero::Hero(double width, double height, double x, double y) : MyGameObject(width,height,x,y) {
}

Hero::~Hero() {
}


void Hero::render() {
	cout << "The Hero is at position (" << x_ << "," << y_
			<< ") and its size is (" << width_ << "," << height_ << ")" << endl;
}

void Hero::update() {
	x_ += 10;
	y_ += 10;
}
