// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once

#include <iostream>
#include <string>

#include <assert.h>

using namespace std;

/*
 *
 */
class Singleton {
public:
	virtual ~Singleton() {}

	static void init(string id) {
		if (instance_ == nullptr) {
			instance_ = new Singleton(id);
		}
	}

	static Singleton* instance() {
		assert( instance_ != nullptr );
		return instance_;
	}
	void foo() {
		cout << "This is foo of " << id_ << endl;
	}

	Singleton(Singleton&) = delete;
	Singleton& operator=(const Singleton&) = delete;

private:
	Singleton(string id) : id_(id) {}
	static Singleton* instance_;
	string id_;

};

