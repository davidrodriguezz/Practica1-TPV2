// This file is part of the course TPV2@UCM - Samir Genaim

#include "Singleton.h"


int main() {
	Singleton::init("The Singleton");
	Singleton::instance()->foo();

	return 0;
}
