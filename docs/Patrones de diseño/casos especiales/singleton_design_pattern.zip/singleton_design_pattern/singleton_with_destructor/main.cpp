#include "Singleton.h"


int main() {
	Singleton::instance();

	std::cout << "End of main ..." << std::endl;
	return 0;
}
