#include "Singleton.h"

#include <iostream>

Singleton* Singleton::instance_ = nullptr;
Destructor<Singleton> Singleton::instanceManager_;

