// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once

#include <iostream>
#include "Destructor.h"

/*
 *
 */
class Singleton {
public:
	Singleton() {
	}
	virtual ~Singleton() {
		std::cout << "Destructor called ..." << std::endl;
	}
	static Singleton* instance() {
		if (instance_ == nullptr) {
			instance_ = new Singleton();
			instanceManager_.setObject(instance_);
		}

		return instance_;
	}
	Singleton(Singleton&) = delete;
	Singleton& operator=(const Singleton&) = delete;

private:
	static Singleton* instance_;
	static Destructor<Singleton> instanceManager_;

};

