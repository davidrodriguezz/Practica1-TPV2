// This file is part of the course TPV2@UCM - Samir Genaim

#pragma once

#include <iostream>
#include <string>

using namespace std;

/*
 *
 */
class Singleton {
public:
	virtual ~Singleton() {
	}

	static void init(string id) {
		if (!initialised_) {
			instance_.id_ = id;
			initialised_ = true;
		}
	}

	static Singleton* instance() {
		if (!initialised_) {
			init("The Singleton!");
		}

		return &instance_;
	}

	void foo() {
		cout << "This is foo of " << id_ << endl;
	}

	Singleton(Singleton&) = delete;
	Singleton& operator=(const Singleton&) = delete;

private:
	Singleton() :
			id_("") {
	}
	static Singleton instance_;
	static bool initialised_;
	string id_;

};

