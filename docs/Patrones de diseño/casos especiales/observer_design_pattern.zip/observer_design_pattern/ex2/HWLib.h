#pragma once


#include <fstream>
#include <string>
#include <iostream>

using namespace std;

class HWLib {
public:
    static double getTempFromDevice(string filename) {
        double temp;
        ifstream dev("/tmp/"+filename);
        dev >> temp;
        dev.close();
        return temp;
    }
};
