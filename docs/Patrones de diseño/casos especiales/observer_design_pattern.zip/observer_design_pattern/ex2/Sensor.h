#pragma once


#include "HWLib.h"
#include "Cooling.h"
#include "Heating.h"

class Sensor {
    double temp_;
    string id_;
    
    Cooling* cooling_;
    Heating* heating_;
public:
    Sensor(string id) : temp_(0), id_(id), cooling_(nullptr), heating_(nullptr) {
        update();
    }
    void setCoolingDevice(Cooling* cooling) {
        this->cooling_ = cooling;
    }
    void setHeatingDevice(Heating* heating) {
        this->heating_ = heating;
    }
    double getCurrTemp() {
        return temp_;
    }
    void update() {
        double currTemp = HWLib::getTempFromDevice(id_);
        if ( temp_ != currTemp ) {
            temp_ = currTemp;
            if ( cooling_ ) cooling_->tempChanged(temp_);
            if ( heating_ ) heating_->tempChanged(temp_);
        }
    }
};

