#pragma once

class Cooling {
public:
	virtual ~Cooling() {
	}
	virtual void turnCoolingOn() = 0;
	virtual void turnCoolingOff() = 0;
	virtual bool isOn() = 0;
};
