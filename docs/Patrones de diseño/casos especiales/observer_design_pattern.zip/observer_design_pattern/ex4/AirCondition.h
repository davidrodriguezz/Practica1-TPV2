#pragma once

#include <string>
#include <iostream>
#include "Cooling.h"
#include "Observer.h"
#include "TempStrategy.h"

using namespace std;

class AirCondition: public Cooling, public Observer {
	bool status_;
	string id_;
	TempStrategy* ts_;

public:
	AirCondition(string id) :
			status_(false), id_(id), ts_(nullptr) {
	}
	bool isOn() {
		return status_;
	}
	void turnCoolingOn() {
		if (isOn())
			return;
		status_ = true;
		cout << id_ << " " << "is on" << endl;
	}
	void turnCoolingOff() {
		if (!isOn())
			return;
		status_ = false;
		cout << id_ << " " << "is off" << endl;
	}
	void setTempStrategy(TempStrategy* ts) {
		this->ts_ = ts;
	}
	void notify(Observer::Event e, Observer::Info i) {
		if (e == _TEMP_CHANGED) {
			switch (ts_->nextStatus(i.temp)) {
			case TempStrategy::_TURN_ON:
				turnCoolingOn();
				break;
			case TempStrategy::_TURN_OFF:
				turnCoolingOff();
				break;
			default:
				break;
			}
		}
	}
};

