#pragma once

#include <string>
#include <iostream>
#include "Heating.h"
#include "Observer.h"
#include "TempStrategy.h"

using namespace std;

class RadiatorHeater: public Heating, public Observer {
	bool status_;
	string id_;
	TempStrategy* ts_;

public:
	RadiatorHeater(string id) :
			status_(false), id_(id), ts_(nullptr) {
	}
	bool isOn() {
		return status_;
	}
	void setTempStrategy(TempStrategy* ts) {
		this->ts_ = ts;
	}
	void turnHeatingOn() {
		if (isOn())
			return;
		status_ = true;
		cout << id_ << " " << "is on" << endl;
	}
	void turnHeatingOff() {
		if (!isOn())
			return;
		status_ = false;
		cout << id_ << " " << "is off" << endl;
	}
	void notify(Observer::Event e, Observer::Info i) {
		if (e == _TEMP_CHANGED) {
			switch (ts_->nextStatus(i.temp)) {
			case TempStrategy::_TURN_ON:
				turnHeatingOn();
				break;
			case TempStrategy::_TURN_OFF:
				turnHeatingOff();
				break;
			default:
				break;
			}
		}
	}

};
