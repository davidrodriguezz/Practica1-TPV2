#pragma once

#include "TempStrategy.h"

class HeatingStrategy: public TempStrategy {
	double min_;
	double max_;
public:
	HeatingStrategy(double min, double max) :
			min_(min), max_(max) {
	}

	Status nextStatus(double temp) {
		if (temp < min_)
			return _TURN_ON;
		else if (temp > max_)
			return _TURN_OFF;
		else
			return _NONE;
	}

};
