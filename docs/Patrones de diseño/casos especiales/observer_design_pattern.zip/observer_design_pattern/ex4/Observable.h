#pragma once

#include "Observer.h"

class Observable {
public:
	virtual ~Observable() {
	}
	virtual void addObserver(Observer* o) = 0;
	virtual void removeObserver(Observer* o) = 0;
};
