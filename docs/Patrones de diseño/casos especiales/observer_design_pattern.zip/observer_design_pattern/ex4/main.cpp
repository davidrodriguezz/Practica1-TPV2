#include <iostream>
#include <unistd.h>
#include <chrono>
#include <thread>
#include "RadiatorHeater.h"
#include "AirCondition.h"
#include "Sensor.h"
#include "CoolingStrategy.h"
#include "HeatingStrategy.h"
#include "TempStrategy.h"

using namespace std;

void doStuff() {

	TempStrategy* st1 = new HeatingStrategy(10, 30);
	TempStrategy* st2 = new CoolingStrategy(10, 30);

	AirCondition a1("AC");
	RadiatorHeater h1("HR");

	a1.turnCoolingOn();
	h1.turnHeatingOff();

	a1.setTempStrategy(st2);
	h1.setTempStrategy(st1);

	Sensor s("S1");

	s.addObserver(&a1);
	s.addObserver(&h1);

	while (true) {
		std::this_thread::sleep_for(std::chrono::milliseconds(2000));
		cout << "Updating ..." << endl;
		s.update();
	}

	delete st1;
	delete st2;

}

int main() {
	doStuff();
}

