#pragma once

class Observer {
public:
	enum Event {
		_TEMP_CHANGED
	};
	typedef struct {
		double temp;
	} Info;
	virtual ~Observer() {
	}
	virtual void notify(Event e, Info info) = 0;
};
