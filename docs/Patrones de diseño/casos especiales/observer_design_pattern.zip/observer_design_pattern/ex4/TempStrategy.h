#pragma once


class TempStrategy {
public:
	enum Status {
		_TURN_ON, _TURN_OFF, _NONE
	};

	virtual ~TempStrategy() {
	}
	virtual Status nextStatus(double temp) = 0;
};
