#pragma once

#include "HWLib.h"
#include "Cooling.h"
#include "Heating.h"

class Sensor {
	double temp_;
	string id_;

	Cooling* cooling_;
	Heating* heating_;
public:
	Sensor(string id) :
			temp_(0), id_(id), cooling_(nullptr), heating_(nullptr) {
		update();
	}
	void setCoolingDevice(Cooling* cooling) {
		cooling_ = cooling;
	}
	void setHeatingDevice(Heating* heating) {
		heating_ = heating;
	}
	double getCurrTemp() {
		return temp_;
	}
	void update() {
		double currTemp = HWLib::getTempFromDevice(id_);
		if (temp_ != currTemp) {
			temp_ = currTemp;
			if (temp_ > 30) {
				if (cooling_)
					cooling_->turnCoolingOn();
				if (heating_)
					heating_->turnHeatingOff();
			} else if (temp_ < 20) {
				if (cooling_)
					cooling_->turnCoolingOff();
				if (heating_)
					heating_->turnHeatingOn();
			}
		}
	}
};

