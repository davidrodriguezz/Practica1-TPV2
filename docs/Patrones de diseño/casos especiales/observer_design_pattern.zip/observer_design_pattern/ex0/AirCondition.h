#pragma once

#include <string>
#include <iostream>
#include "Cooling.h"

using namespace std;

class AirCondition: public Cooling {
public:
	AirCondition(string id) :
			status_(false), id_(id) {
	}
	bool isOn() {
		return status_;
	}
	void turnCoolingOn() {
		if (isOn())
			return;

		status_ = true;
		cout << id_ << " " << "is on" << endl;
	}
	void turnCoolingOff() {
		if (!isOn())
			return;

		status_ = false;
		cout << id_ << " " << "is off" << endl;
	}
private:
	bool status_;
	string id_;
};

