#pragma once

#include <string>
#include <iostream>
#include "Cooling.h"
#include "Observer.h"

using namespace std;

class AirCondition: public Cooling, public Observer {
	bool status;
	string id;
public:
	AirCondition(string id) :
			status(false), id(id) {
	}
	bool isOn() {
		return status;
	}
	void turnCoolingOn() {
		if (isOn())
			return;
		status = true;
		cout << id << " " << "is on" << endl;
	}
	void turnCoolingOff() {
		if (!isOn())
			return;
		status = false;
		cout << id << " " << "is off" << endl;
	}
	void onNotify(Observer::Event e, Observer::Info i) {
		if (e == _TEMP_CHANGED) {
			if (i.temp > 30) {
				turnCoolingOn();
			} else if (i.temp < 20) {
				turnCoolingOff();
			}
		}
	}
};

