#pragma once


#include "HWLib.h"
#include "AirCondition.h"
#include "Observable.h"
#include "RadiatorHeater.h"
#include "Observer.h"

class Sensor: public Observable {
	double temp_;
	string id_;

	static const int MAX_OBSERVERS = 100;
	Observer* observers_[MAX_OBSERVERS];
	int numOfObservers_;

public:
	Sensor(string id) :
			temp_(0), id_(id), numOfObservers_(0) {
		update();
	}
	double getCurrTemp() {
		return temp_;
	}
	void addObserver(Observer* o) {
		observers_[numOfObservers_++] = o;
	}
	void removeObserver(Observer* o) {
		// not implemented ...
	}

	void update() {
		Observer::Info info;
		info.temp = HWLib::getTempFromDevice(id_);
		if (temp_ != info.temp) {
			temp_ = info.temp;
			for (int i = 0; i < numOfObservers_; i++)
				observers_[i]->onNotify(Observer::_TEMP_CHANGED, info);
		}
	}

};
