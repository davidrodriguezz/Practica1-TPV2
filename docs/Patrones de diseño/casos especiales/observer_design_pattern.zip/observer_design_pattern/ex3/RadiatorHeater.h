#pragma once

#include <string>
#include <iostream>
#include "Heating.h"
#include "Observer.h"

using namespace std;

class RadiatorHeater: public Heating, public Observer {
	bool status;
	string id;
public:
	RadiatorHeater(string id) :
			status(false), id(id) {
	}
	bool isOn() {
		return status;
	}
	void turnHeatingOn() {
		status = true;
		cout << id << " " << "is on" << endl;
	}
	void turnHeatingOff() {
		status = false;
		cout << id << " " << "is off" << endl;
	}
	void onNotify(Observer::Event e, Observer::Info i) {
		if (e == _TEMP_CHANGED) {
			if (i.temp > 30) {
				turnHeatingOff();
			} else if (i.temp < 20) {
				turnHeatingOn();
			}
		}
	}

};
