
#include <iostream>
#include <chrono>
#include <thread>
#include "RadiatorHeater.h"
#include "AirCondition.h"
#include "Sensor.h"

using namespace std;

void doStuff() {
	AirCondition a1("AC1");
	RadiatorHeater h1("HR1");
	AirCondition a2("AC2");
	RadiatorHeater h2("HR2");
	Sensor s("S1");

	s.addObserver(&a1);
	s.addObserver(&h1);
	s.addObserver(&a2);
	s.addObserver(&h2);

	a1.turnCoolingOn();
	h1.turnHeatingOff();

	while (true) {
		std::this_thread::sleep_for(std::chrono::milliseconds(2000));
		cout << "Updating ..." << endl;
		s.update();
	}
}

int main() {
	doStuff();
}

