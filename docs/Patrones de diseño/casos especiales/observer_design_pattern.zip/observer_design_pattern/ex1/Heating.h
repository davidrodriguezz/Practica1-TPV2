#pragma once


class Heating {
public:
	virtual ~Heating() {
	}
	virtual void turnHeatingOn() = 0;
	virtual void turnHeatingOff() = 0;
	virtual bool isOn() = 0;
	virtual void tempChanged(double) = 0;
};
