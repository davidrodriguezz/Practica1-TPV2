#pragma once

#include <string>
#include <iostream>
#include "Cooling.h"

using namespace std;

class AirCondition: public Cooling {
	bool status_;
	string id_;
public:
	AirCondition(string id) : status_(false), id_(id) {
	}
	bool isOn() {
		return status_;
	}
	void turnCoolingOn() {
		if (isOn())
			return;

		status_ = true;
		cout << id_ << " " << "is on" << endl;
	}
	void turnCoolingOff() {
		if (!isOn())
			return;

		status_ = false;
		cout << id_ << " " << "is off" << endl;
	}
	void tempChanged(double temp) {
		if (temp > 30) {
			turnCoolingOn();
		} else if (temp < 20) {
			turnCoolingOff();
		}
	}

};
