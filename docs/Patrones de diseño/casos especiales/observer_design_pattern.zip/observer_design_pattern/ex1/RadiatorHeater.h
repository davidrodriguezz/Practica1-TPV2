#pragma once


#include <stdio.h>
#include <string>
#include <iostream>
#include "Heating.h"

using namespace std;

class RadiatorHeater : public Heating {
    bool status_;
    string id_;
public:
    RadiatorHeater(string id) : status_(false), id_(id) {
    }
    bool isOn() {
        return status_;
    }
    void turnHeatingOn() {
        if ( isOn() ) return;
        status_ = true;
        cout << id_ << " " << "is on" << endl;
    }
    void turnHeatingOff() {
        if ( !isOn() ) return;
        status_ = false;
        cout << id_ << " " << "is off" << endl;
    }
    void tempChanged(double temp) {
        if ( temp>30 ) {
            turnHeatingOn();
        } else if ( temp<20 ) {
            turnHeatingOff();
        }
    }
};

