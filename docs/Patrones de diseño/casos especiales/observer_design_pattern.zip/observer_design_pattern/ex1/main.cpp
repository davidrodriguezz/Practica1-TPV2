

#include <iostream>
#include <chrono>
#include <thread>
#include "RadiatorHeater.h"
#include "AirCondition.h"
#include "Sensor.h"

using namespace std;

void doStuff() {
    AirCondition a("AC");
    RadiatorHeater h("HR");
    
    a.turnCoolingOn();
    h.turnHeatingOff();
    
    Sensor s("S1");
    s.setCoolingDevice(&a);
    s.setHeatingDevice(&h);
    
    while ( true ) {
        std::this_thread::sleep_for(std::chrono::milliseconds(2000));
        cout << "Updating ..." << endl;
        s.update();
    }
}


int main() {
    doStuff();
}


