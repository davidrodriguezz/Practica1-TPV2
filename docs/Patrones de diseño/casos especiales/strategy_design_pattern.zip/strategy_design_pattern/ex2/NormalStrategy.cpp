#include "NormalStrategy.h"
