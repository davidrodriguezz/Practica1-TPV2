#pragma once

#include "Customer.h"

class WeekEndCustomer: public Customer {
public:
	WeekEndCustomer() {
	}

	virtual ~WeekEndCustomer() {
	}

	virtual void add(double price, int quantity) {
		int c = quantity / 3 + (quantity % 3 == 0 ? 0 : 1);
		drinks_.push_back(price * c);
	}
};
