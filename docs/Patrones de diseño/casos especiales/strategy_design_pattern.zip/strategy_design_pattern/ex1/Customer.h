#pragma once

#include <vector>
#include <iostream>

using namespace std;

class Customer {
protected:
	vector<double> drinks_;
public:
	Customer() {
	}

	virtual ~Customer() {
	}

	virtual void add(double price, int quantity) {
		drinks_.push_back(price * quantity);
	}

	virtual void printBill() {
		double total = 0.0;
		for (double p : drinks_) {
			total += p;
		}
		cout << "Total: " << total << endl;
	}
};
